(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f1515f1d._.js",
  "static/chunks/components_c409470c._.js"
],
    source: "dynamic"
});
